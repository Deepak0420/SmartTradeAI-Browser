package com.smarttradeai.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF141E30)
private val Accent = Color(0xFF00E0B0)
private val Muted = Color(0xFF91A0B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartTradeBrowser() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SmartTradeBrowser() {
    val context = LocalContext.current
    val keyStore = remember { SecureKeyStore(context) }
    val scope = rememberCoroutineScope()

    var address by remember { mutableStateOf("https://www.google.com") }
    var pageTitle by remember { mutableStateOf("SmartTradeAI") }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(false) }
    var assistantOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var question by remember { mutableStateOf("") }
    var apiKeyInput by remember { mutableStateOf("") }
    var desktopMode by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf("नमस्ते! Gemini AI से सवाल पूछें या खुले हुए chart का analysis करें।") }
    var keyStatus by remember { mutableStateOf(if (keyStore.read().isNullOrBlank()) "API key सेट नहीं है" else "Gemini key सुरक्षित रूप से सेव है") }

    fun openPage(input: String) {
        val value = input.trim()
        if (value.isBlank()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
        }
        address = url
        webView?.loadUrl(url)
    }

    fun capturePage(): Bitmap? {
        val view = webView ?: return null
        if (view.width <= 0 || view.height <= 0) return null
        return try {
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            bitmap
        } catch (_: Exception) { null }
    }

    fun sendToGemini(prompt: String, includePage: Boolean) {
        val key = keyStore.read()
        if (key.isNullOrBlank()) {
            reply = "पहले Settings खोलकर अपनी Gemini API key सेव करें। Key इस फोन में encrypted रहेगी।"
            settingsOpen = true
            return
        }
        if (prompt.isBlank() && !includePage) return
        busy = true
        reply = "Gemini जवाब तैयार कर रहा है…"
        val image = if (includePage) capturePage() else null
        val actualPrompt = if (includePage) {
            (prompt.ifBlank { "इस chart/screen को ध्यान से देखकर analysis करें।" }) +
                "\n\nTrading safety: केवल दिखाई दे रहे संकेत बताएं, निश्चित भविष्यवाणी न करें। Trend, support/resistance, candles और risk समझाएं। अगर chart/data स्पष्ट नहीं है तो साफ बताएं।"
        } else prompt
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                try { GeminiClient.ask(key, actualPrompt, image) }
                catch (e: Exception) { "Request पूरा नहीं हुआ: ${e.message ?: "Unknown error"}" }
            }
            reply = result
            busy = false
            question = ""
        }
    }

    BackHandler(enabled = assistantOpen || settingsOpen || webView?.canGoBack() == true) {
        when {
            settingsOpen -> settingsOpen = false
            assistantOpen -> assistantOpen = false
            else -> webView?.goBack()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(42.dp).background(Accent.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("S", color = Accent, fontSize = 27.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("SmartTradeAI", color = Color.White, fontSize = 20.sp)
                        Text("INTELLIGENT BROWSER • GEMINI", color = Accent, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { settingsOpen = true }) { Text("⚙", color = Accent, fontSize = 20.sp) }
                }

                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(Panel, RoundedCornerShape(15.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = address, onValueChange = { address = it }, modifier = Modifier.weight(1f),
                        singleLine = true, placeholder = { Text("Search or enter website", color = Muted) },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { openPage(address) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Accent, unfocusedBorderColor = Color.Transparent, cursorColor = Accent
                        )
                    )
                    TextButton(onClick = { openPage(address) }) { Text("GO", color = Accent) }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { if (webView?.canGoBack() == true) webView?.goBack() }) { Text("‹", color = Color.White, fontSize = 20.sp) }
                    TextButton(onClick = { if (webView?.canGoForward() == true) webView?.goForward() }) { Text("›", color = Color.White, fontSize = 20.sp) }
                    TextButton(onClick = { webView?.reload() }) { Text("↻", color = Color.White, fontSize = 20.sp) }
                    TextButton(onClick = { openPage("https://www.google.com") }) { Text("⌂", color = Accent, fontSize = 20.sp) }
                    TextButton(onClick = {
                        desktopMode = !desktopMode
                        webView?.settings?.useWideViewPort = true
                        webView?.settings?.loadWithOverviewMode = true
                        webView?.settings?.userAgentString = if (desktopMode) null else
                            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36"
                        webView?.reload()
                    }) { Text(if (desktopMode) "Mobile" else "Desktop", color = Accent, fontSize = 11.sp) }
                }

                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent, trackColor = Panel)

                AndroidView(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, progress: Int) { loading = progress < 100 }
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    url?.let { address = it }
                                    pageTitle = view?.title ?: "SmartTradeAI"
                                }
                            }
                            webView = this
                            loadUrl("https://www.google.com")
                        }
                    },
                    update = { webView = it }
                )

                Row(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = { openPage("https://www.google.com") }) { Text("⌂\nHome", color = Accent, fontSize = 11.sp) }
                    TextButton(onClick = { assistantOpen = true }) { Text("✦\nGemini AI", color = Accent, fontSize = 11.sp) }
                    TextButton(onClick = { webView?.reload() }) { Text("↻\nRefresh", color = Color.White, fontSize = 11.sp) }
                    TextButton(onClick = { settingsOpen = true }) { Text("⚙\nSettings", color = Color.White, fontSize = 11.sp) }
                }
            }

            if (assistantOpen) {
                Card(
                    Modifier.align(Alignment.BottomCenter).padding(12.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✦ Gemini Trading Assistant", color = Accent, fontSize = 17.sp)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { assistantOpen = false }) { Text("✕", color = Muted) }
                        }
                        Text("Page: $pageTitle", color = Muted, fontSize = 10.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(reply, color = Color.White, fontSize = 13.sp, lineHeight = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = question, onValueChange = { question = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Trend, RSI, support/resistance के बारे में पूछें…", color = Muted) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Accent, unfocusedBorderColor = Muted)
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { sendToGemini(question, false) }, enabled = !busy,
                                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                            ) { Text(if (busy) "WAIT…" else "SEND") }
                            Button(
                                onClick = { sendToGemini(question, true) }, enabled = !busy,
                                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263A55), contentColor = Color.White)
                            ) { Text("ANALYZE SCREEN") }
                        }
                        Text("Screen analysis केवल इसी browser page का screenshot भेजता है। कोई automatic trade नहीं।", color = Muted, fontSize = 9.sp)
                    }
                }
            }

            if (settingsOpen) {
                AlertDialog(
                    onDismissRequest = { settingsOpen = false },
                    containerColor = Panel,
                    title = { Text("Gemini API Settings", color = Color.White) },
                    text = {
                        Column {
                            Text(keyStatus, color = Accent, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = apiKeyInput, onValueChange = { apiKeyInput = it },
                                modifier = Modifier.fillMaxWidth(), singleLine = true,
                                label = { Text("Gemini API key") },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Accent, unfocusedBorderColor = Muted)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("Key इस फोन के Android Keystore से encrypt होकर सेव होगी। इसे ChatGPT या GitHub पर paste न करें।", color = Muted, fontSize = 10.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            keyStore.save(apiKeyInput)
                            apiKeyInput = ""
                            keyStatus = if (keyStore.read().isNullOrBlank()) "API key सेट नहीं है" else "Gemini key सुरक्षित रूप से सेव है"
                            settingsOpen = false
                        }) { Text("SAVE SECURELY", color = Accent) }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            keyStore.clear()
                            apiKeyInput = ""
                            keyStatus = "API key हटाई गई"
                        }) { Text("CLEAR KEY", color = Color(0xFFFF7777)) }
                    }
                )
            }
        }
    }
}
