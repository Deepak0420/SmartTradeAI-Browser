# SmartTradeAI Browser V2 Upgrade (Hindi)

## इस पैकेज में क्या बदला है
- Gemini API के साथ वास्तविक text chat connection (`gemini-2.5-flash`, REST `generateContent`)
- खुले हुए browser page का screenshot लेकर Gemini से chart/screen analysis
- Gemini API key को Android Keystore AES-GCM encryption के साथ फोन पर save करना
- Premium browser UI, address bar, back/forward, refresh और desktop mode बरकरार

## जरूरी सुरक्षा/सीमाएं
- API key को GitHub, README, source code या ChatGPT chat में कभी paste न करें।
- App में key save करना device पर encrypted है, लेकिन client-side app में मौजूद key को rooted/compromised device से पूरी तरह सुरक्षित नहीं माना जा सकता।
- Gemini API usage आपके Google AI Studio account की quota/billing limits के अधीन है।
- Screen analysis सिर्फ SmartTradeAI Browser के खुले WebView का screenshot भेजता है। यह दूसरी apps की screen capture नहीं करता।
- यह app कोई trade place/click नहीं करता, order/withdrawal नहीं करता। Gemini का chart analysis निश्चित भविष्यवाणी नहीं है।
- Binomo Crypto IDX/OTC और Binance market data एक ही feed नहीं माने जाएंगे।

## GitHub पर लगाना
1. Repo खोलें: https://github.com/Deepak0420/SmartTradeAI-Browser
2. `app/src/main/java/com/smarttradeai/browser/` में `SecureKeyStore.kt` और `GeminiClient.kt` नाम की नई files बनाएं और ZIP से उनका पूरा code paste करें।
3. इसी folder की `MainActivity.kt` को पूरी तरह replace करें।
4. `app/build.gradle.kts` को ZIP वाले version से replace करें।
5. Commit changes करें। Root `gradle.properties`, workflow और बाकी files को न बदलें।
6. GitHub → Actions में `SmartTradeAI Android Build` run पूरा होने दें।
7. Build successful हो तभी Artifacts से APK डाउनलोड करें।

## फोन पर पहली बार
1. APK install करें।
2. App में ⚙ Settings खोलें।
3. Google AI Studio से बनाई हुई Gemini API key सीधे app में paste करके SAVE SECURELY दबाएं।
4. Browser में chart खोलें → Gemini AI → ANALYZE SCREEN।

## अभी इस V2 में शामिल नहीं
- दूसरे apps के ऊपर चलने वाला true floating assistant overlay
- Android MediaProjection से दूसरी apps की screen capture
- Multi-tab manager, history/bookmarks/download manager, voice conversation
इनको अलग चरण में जोड़ना और फोन पर test करना होगा; इस पैकेज में इनकी completion का दावा नहीं है।
