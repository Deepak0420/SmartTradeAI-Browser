package com.smarttradeai.browser

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    fun ask(apiKey: String, prompt: String, screenshot: Bitmap? = null): String {
        require(apiKey.isNotBlank()) { "Settings में Gemini API key सेव करें।" }

        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt))

        screenshot?.let { bitmap ->
            val scaled = scale(bitmap, 1280)
            val bytes = ByteArrayOutputStream().use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
                out.toByteArray()
            }
            val inline = JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
            parts.put(JSONObject().put("inline_data", inline))
        }

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.35).put("maxOutputTokens", 1200))

        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) {
                val message = try {
                    JSONObject(response).optJSONObject("error")?.optString("message")
                } catch (_: Exception) { null }
                throw IllegalStateException("Gemini API error ($code): ${message ?: response.take(300)}")
            }
            val json = JSONObject(response)
            val candidates = json.optJSONArray("candidates")
            val content = candidates?.optJSONObject(0)?.optJSONObject("content")
            val responseParts = content?.optJSONArray("parts")
            val result = buildString {
                if (responseParts != null) {
                    for (i in 0 until responseParts.length()) {
                        val part = responseParts.optJSONObject(i)
                        val text = part?.optString("text").orEmpty()
                        if (text.isNotBlank()) append(text).append('\n')
                    }
                }
            }.trim()
            if (result.isBlank()) "AI से खाली जवाब मिला। कृपया दोबारा कोशिश करें।" else result
        } finally {
            connection.disconnect()
        }
    }

    private fun scale(source: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(source.width, source.height)
        if (longest <= maxSide) return source
        val ratio = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(
            source,
            (source.width * ratio).toInt().coerceAtLeast(1),
            (source.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }
}
